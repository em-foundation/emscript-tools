Blackhawk(tm) Utility Folder README

===================================
Blackhawk

123 Gaither Drive
Mount Laurel, New Jersey 08054-1701

Tel: +1 (856) 234-2629

http://www.blackhawk-dsp.com
===================================
2011 (c) EWA Technologies, Inc.



***The Utility folder is not currently supported under Linux.


FOR LAN560 CONFIGURATION - See "bhnetcfg" in common\uscif folder.
FOR LAN560 STATUS        - See "BhEthStatus" in common\uscif folder.

EOF
