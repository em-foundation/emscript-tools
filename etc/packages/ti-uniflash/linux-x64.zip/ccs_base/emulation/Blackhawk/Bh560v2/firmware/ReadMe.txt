
Blackhawk XDS560v2 Firmware can be found here:
	http://www.blackhawk-dsp.com/support/xds560v2
	