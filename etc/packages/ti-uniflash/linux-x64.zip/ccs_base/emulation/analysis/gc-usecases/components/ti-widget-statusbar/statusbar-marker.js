/*
 * This file is intended to be blank to assist locating the container folder url with in javascript.
 */